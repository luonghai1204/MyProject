/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.BookManagementDAO;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Book;
import model.BookType;

/**
 *
 * @author Uchitachi
 */
public class BMUpdateBookController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
//            String bookId = "1016A83B-4F17-4FE6-9163-D7ECE6030773";
            String bookId = request.getParameter("id");
            Book book = new Book();
            ArrayList<BookType> bookTypes = new ArrayList<>();
            BookManagementDAO DAO = new BookManagementDAO();
            
            book = DAO.GetBookById(bookId);
            bookTypes = DAO.getTypeOfBook();
            
            request.setAttribute("book", book);
            request.setAttribute("bookTypes", bookTypes);
            request.getRequestDispatcher("../bookmanagerment/UpdateBook.jsp").forward(request, response);
        } catch (SQLException ex) {
            request.setAttribute("errorMessage", "Error can load data from database");
            request.setAttribute("exceptionMessage", ex.getMessage());
            request.getRequestDispatcher("../Error.jsp").forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html;charset=UTF-8");
            request.setCharacterEncoding("utf-8");
            
            String bookId = request.getParameter("id");
            BookManagementDAO DAO = new BookManagementDAO();
            Book book = new Book();
            // get value from jsp
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            String imageCover = request.getParameter("image");
            if (imageCover.length() <= 0) {
                imageCover = request.getParameter("oldImage");
            }
            String source = request.getParameter("source");
            String status = request.getParameter("status");
            boolean isDelete = request.getParameter("isActive").equals("1") ? true : false;
            String bookTypeId = request.getParameter("bookTypeValue");
            
            // set value to model
            book.setId(UUID.fromString(bookId));
            book.setName(name);
            book.setDescription(description);
            book.setImageCover(imageCover);
            book.setSource(source);
            book.setStatus(status);
            book.setDeleted(isDelete);
            book.setBookTypeId(UUID.fromString(bookTypeId));
            DAO.UpdateBook(book);
            response.sendRedirect("list");
        } catch (SQLException ex) {
            request.setAttribute("errorMessage", "Error can load data from database");
            request.setAttribute("exceptionMessage", ex.getMessage());
            request.getRequestDispatcher("../Error.jsp").forward(request, response);
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
