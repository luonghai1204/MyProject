/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.AdminDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Role;
import model.User;

/**
 *
 * @author Uchitachi
 */
public class AdminUserDetail extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String userId = (String) request.getParameter("id");
            User userDetails = new User();
            AdminDAO adminDao = new AdminDAO();
            ArrayList<Role> roles = new ArrayList<>();
            userDetails = adminDao.GetUserDetails(userId);
            AdminDAO adDAO = new AdminDAO();
            roles = adDAO.getRole();

            request.setAttribute("roles", roles);
            request.setAttribute("userDetails", userDetails);
            request.getRequestDispatcher("../AdminPackage/AdminUserDetail.jsp").forward(request, response);
        } catch (SQLException ex) {
            request.setAttribute("errorMessage", "Error can load data from database");
            request.setAttribute("exceptionMessage", ex.getMessage());
            request.getRequestDispatcher("Error.jsp").forward(request, response);
        }

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String id = (String) request.getParameter("id");
             String roleId = request.getParameter("typeRole");
            boolean isActive = request.getParameter("isActive").equals("1") ? true : false;
            User user = new User();
            user.setRoleId(UUID.fromString(roleId));
            user.setIsActive(isActive);
            user.setId(UUID.fromString(id));
            AdminDAO adminDao = new AdminDAO();
            adminDao.UpdateUser(user);
            response.sendRedirect("listaccount");
        } catch (SQLException ex) {
            request.setAttribute("errorMessage", "Error can load data from database");
            request.setAttribute("exceptionMessage", ex.getMessage());
            request.getRequestDispatcher("Error.jsp").forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
