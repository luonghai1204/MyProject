/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.RegisterDAO;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Role;
import model.User;
import org.mindrot.jbcrypt.BCrypt;

/**
 *
 * @author Uchitachi
 */
public class RegisterController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("Register.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        try {
            // Take list user
            RegisterDAO registerDAO = new RegisterDAO();
            ArrayList<User> listUser = new ArrayList<>();
            listUser = registerDAO.getUser();
            int num = 0;
            //take Role
            Role r = new Role();
            r = registerDAO.getRole();
            // Take info from jsp
            String userName = request.getParameter("userName").trim();
            String password = request.getParameter("password").trim();
            String confirm = request.getParameter("repassword").trim();
            // Hasing password
            String hash = BCrypt.hashpw(password, BCrypt.gensalt(12));

            String firstName = request.getParameter("firstName").trim();
            String lastName = request.getParameter("lastName").trim();
            String email = request.getParameter("email").trim();
            boolean gender = request.getParameter("gender").equals("male");
            Date dob = Date.valueOf(request.getParameter("dob"));
            UUID roleId = r.getId();

            boolean isActive = true;
            // take curren time
            long millis = System.currentTimeMillis();
            java.sql.Date date = new java.sql.Date(millis);
            Date createdAt = date;

            for (User user : listUser) {
                if (user.getUsername().equals(userName) || user.getEmail().equals(email)) {
                    num++;
                }
            }

            if (num == 0) {
                User u = new User();
                u.setUsername(userName);
                u.setPassword(hash);
                u.setFirstName(firstName);
                u.setLastName(lastName);
                u.setEmail(email);
                u.setGender(gender);
                u.setDob(dob);
                u.setCreatedAt(createdAt);
                u.setRoleId(roleId);
                u.setIsActive(isActive);

                RegisterDAO db = new RegisterDAO();
                db.addAccount(u);

                String mess = "add sucessfull";
                String typeText = "text-success";
                request.setAttribute("mess", mess);        
                request.setAttribute("typeText", typeText);
                request.getRequestDispatcher("Register.jsp").forward(request, response);

            } else {
                User u = new User();
                u.setUsername(userName);
                u.setPassword(hash);
                u.setFirstName(firstName);
                u.setLastName(lastName);
                u.setEmail(email);
                u.setGender(gender);
                u.setDob(dob);
                u.setCreatedAt(createdAt);
                u.setRoleId(roleId);
                u.setIsActive(isActive);
                String mess = "username/email đã tồn tại trong hệ thống";
                String typeText = "text-danger";
                request.setAttribute("mess", mess);        
                request.setAttribute("typeText", typeText);
                request.setAttribute("user", u);
                request.setAttribute("password", password);
                request.setAttribute("confirm", confirm);
                request.getRequestDispatcher("Register.jsp").forward(request, response);
            }
        } catch (SQLException ex) {
            request.setAttribute("errorMessage", "Error can load data from database");
            request.setAttribute("exceptionMessage", ex.getMessage());
            request.getRequestDispatcher("Error.jsp").forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
