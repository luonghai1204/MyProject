/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.BookManagementDAO;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Book;
import model.BookType;

/**
 *
 * @author Uchitachi
 */
public class BMCreateBookController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            BookManagementDAO DAO = new BookManagementDAO();
            ArrayList<BookType> bookTypes = new ArrayList<>();
            bookTypes = DAO.getTypeOfBook();
            request.setAttribute("bookTypes", bookTypes);
            request.getRequestDispatcher("../bookmanagerment/CreateBook.jsp").forward(request, response);
        } catch (SQLException ex) {
            request.setAttribute("errorMessage", "Error can load data from database");
            request.setAttribute("exceptionMessage", ex.getMessage());
            request.getRequestDispatcher("../Error.jsp").forward(request, response);
        }

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            BookManagementDAO DAO = new BookManagementDAO();
            Book book = new Book();
            BookType bookType = new BookType();
            // get value from jsp
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            String imageCover = request.getParameter("image");
            String source = request.getParameter("source");
            String status = request.getParameter("status");
            boolean isDelete = false;
            String bookTypeId = request.getParameter("bookTypeValue");

            // set value to model
            book.setName(name);
            book.setDescription(description);
            book.setImageCover(imageCover);
            book.setSource(source);
            book.setStatus(status);
            book.setDeleted(isDelete);
            bookType.setId(UUID.fromString(bookTypeId));
            DAO.CreateBook(book, bookType);
            response.sendRedirect("../bookmanage/createbook");
        } catch (SQLException ex) {
            request.setAttribute("errorMessage", "Error can load data from database");
            request.setAttribute("exceptionMessage", ex.getMessage());
            request.getRequestDispatcher("../Error.jsp").forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
