/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ChapterDAO;
import dao.CommentDAO;
import dao.ReaderDAO;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Author;
import model.Book;
import model.Chapter;
import model.Comment;
import model.User;

/**
 *
 * @author Uchitachi
 */
public class ReaderBookDetailController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String bookId = request.getParameter("id");
            ReaderDAO readerDao = new ReaderDAO();
            Book book = readerDao.GetBookById(bookId);
            Author author = readerDao.GetAuthorByBookId(bookId);

            int pagesize = 5;
            String raw_pageindex = request.getParameter("page");

            if (raw_pageindex == null || raw_pageindex.equals("")) {
                raw_pageindex = "1";
            }
            int pageindex = Integer.parseInt(raw_pageindex);
//          Get List chapter
            ChapterDAO chapterDao = new ChapterDAO();
            ArrayList<Chapter> listChapter = chapterDao.getListChapterByBook(pagesize, pageindex, bookId);

            int totalRows = chapterDao.countChapters(bookId);
            int totalPage = totalRows / pagesize + (totalRows % pagesize > 0 ? 1 : 0);

//           Get list Comment
            ArrayList<Comment> comments = new ArrayList<>();
            ArrayList<User> users = new ArrayList<>();
            CommentDAO DAO = new CommentDAO();
            comments = DAO.GetListComment(bookId);
            users = DAO.GetUsernameByBookId(bookId);
            request.setAttribute("bookId", bookId);
            request.setAttribute("comments", comments);
            request.setAttribute("users", users);

            request.setAttribute("pageindex", pageindex);
            request.setAttribute("totalpage", totalPage);
            request.setAttribute("listChapter", listChapter);

            request.setAttribute("book", book);
            request.setAttribute("author", author);

            request.getRequestDispatcher("../readerScreen/BookDetail.jsp").forward(request, response);
        } catch (SQLException ex) {
            request.setAttribute("errorMessage", "Error can load data from database");
            request.setAttribute("exceptionMessage", ex.getMessage());
            request.getRequestDispatcher("../Error.jsp").forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String userId = request.getParameter("userId");
            String bookId = request.getParameter("bookId");
            String commentContent = request.getParameter("commentContent").trim();
            CommentDAO DAO = new CommentDAO();
            DAO.CreateComment(bookId, userId, commentContent);
            response.sendRedirect("bookdetail?id="+bookId);
        } catch (SQLException ex) {
            request.setAttribute("errorMessage", "Error can load data from database");
            request.setAttribute("exceptionMessage", ex.getMessage());
            request.getRequestDispatcher("../Error.jsp").forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
