/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.BookManagementDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Book;
import model.Chapter;

/**
 *
 * @author Uchitachi
 */
public class BMCreateChapterController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String bookId = request.getParameter("bookId");
        request.setAttribute("bookId", bookId);
        request.getRequestDispatcher("../bookmanagerment/CreateChapter.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html;charset=UTF-8");
            request.setCharacterEncoding("utf-8");
            
            // Initialized model container.
            BookManagementDAO DAO = new BookManagementDAO();
            Book book = new Book();
            Chapter chapter = new Chapter();

            // Get value from jsp.
            int order = Integer.valueOf(request.getParameter("order").trim());
            String bookId = request.getParameter("bookId");
            String chapterName = request.getParameter("name").trim();
            String content = request.getParameter("content").trim();
            String image = request.getParameter("image").trim();

            // Set value to model
            book.setId(UUID.fromString(bookId));
            chapter.setOrder(order);
            chapter.setName(chapterName);
            chapter.setContent(content);
            chapter.setImageCover(image);

            // Get chapter by id to check chapter exist
            ArrayList<Integer> listChapterById = DAO.GetChapterExistById(bookId);
            boolean isExist = false;
            for (Integer temp : listChapterById) {
                if (temp == order) {
                    isExist = true;
                    break;
                }
            }
            if (!isExist) {
                // Create chapter.
                DAO.CreateChapter(book, chapter);
                response.sendRedirect("listchapter?bookId="+ bookId);
            } else {
                String textMess = "text-danger";
                String mess = "Create Chapter Fail: Chapter exist!";
                request.setAttribute("textMess", textMess);
                request.setAttribute("chapter", chapter);
                request.setAttribute("mess", mess);
                request.setAttribute("bookId", bookId);
               request.getRequestDispatcher("../bookmanagerment/CreateChapter.jsp").forward(request, response);
            }
        } catch (SQLException ex) {
            Logger.getLogger(BMCreateChapterController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
