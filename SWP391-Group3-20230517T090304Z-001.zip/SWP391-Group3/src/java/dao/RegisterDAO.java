/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dao.interf.RegisterDAOInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import model.Role;
import model.User;

/**
 *
 * @author Uchitachi
 */
public class RegisterDAO extends DBContext implements RegisterDAOInterface{
    
    // Add information of user into database
    @Override
    public void addAccount(User u) throws SQLException{
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        
        try {
            String sql = "INSERT INTO [dbo].[User]\n"
                    + "           ([username]\n"
                    + "           ,[password]\n"
                    + "           ,[firstName]\n"
                    + "           ,[lastName]\n"
                    + "           ,[email]\n"
                    + "           ,[roleId]\n"
                    + "           ,[gender]\n"
                    + "           ,[dob]\n"
                    + "           ,[createdAt]\n"
                    + ",[isActive])\n"
                    + "     VALUES\n"
                    + "           (?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + ",?)";
            

            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getFirstName());
            ps.setString(4, u.getLastName());
            ps.setString(5, u.getEmail());
            ps.setString(6, String.valueOf(u.getRoleId()));
            ps.setBoolean(7, u.isGender());
            ps.setDate(8, u.getDob());
            ps.setDate(9, u.getCreatedAt());
            ps.setBoolean(10, u.isIsActive());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw e;
        }finally{
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }

    }

    // Get information of user from databse
    @Override
    public ArrayList<User> getUser() throws SQLException{
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        
        ArrayList<User> us = new ArrayList<>();
        try {
            String sql = "SELECT [id]\n"
                    + "      ,[username]\n"
                    + "      ,[password]\n"
                    + "      ,[firstName]\n"
                    + "      ,[lastName]\n"
                    + "      ,[email]\n"
                    + "      ,[roleId]\n"
                    + "      ,[gender]\n"
                    + "      ,[dob]\n"
                    + "      ,[isActive]\n"
                    + "      ,[deleted]\n"
                    + "      ,[createdAt]\n"
                    + "      ,[updatedAt]\n"
                    + "  FROM [dbo].[User]";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                User u = new User();
                u.setUsername(rs.getString("username"));
                u.setPassword(rs.getString("password"));
                u.setEmail(rs.getString("email"));
                us.add(u);
            }
        } catch (SQLException e) {
            throw e;
        }finally{
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return us;
    }
    
//    get role Reader from database
    @Override
     public Role getRole() throws SQLException{
        PreparedStatement ps = null;
        ResultSet rs = null; 
        Connection connection = null;
        Role r = new Role();
        try {
            String sql = "SELECT [id]\n"
                    + "      ,[name]\n"
                    + "  FROM [dbo].[Role] WHERE name = 'Reader'";
            connection=openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                
                r.setId(UUID.fromString(rs.getString("id")));
                r.setName(rs.getString("name"));
            }
        } catch (SQLException e) {
           throw e;
        }finally{
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return r;
    }
    
}
