/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import model.Role;
import model.User;

/**
 *
 * @author Uchitachi
 */
public class LoginDAO extends DBContext{
//    get infomation of user from databse(by username)
    public User getAccountByUserNameandPassword(String user) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "SELECT * "
                    + "  FROM [dbo].[User] WHERE username = ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, user);
            rs = ps.executeQuery();
            User u = null;
            while (rs.next()) {
                if (u == null) {
                    u = new User();
                    u.setId(UUID.fromString(rs.getString("id")));
                    u.setUsername(rs.getString("username"));
                    u.setPassword(rs.getString("password"));

                }
            }
            return u;

        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
        }

        
    }
//  get Role of account (by username)
    public Role getAccountRole(String user) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "SELECT r.[id],r.[name],u.[username], u.[password] "
                    + "  FROM [Role] r INNER JOIN [User] u "
                    + "  ON r.id = u.roleId "
                    + "  WHERE u.username = ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, user);
            rs = ps.executeQuery();
            Role role = null;
            while (rs.next()) {
                if (role == null) {
                    role = new Role();
                    role.setName(rs.getString("name"));
                }
            }
            return role;

        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }

    }
}
