/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dao.interf.ReviewDAOInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import model.Book;
import model.Review;
import model.User;

/**
 *
 * @author Uchitachi
 */
public class ReviewDAO extends DBContext implements ReviewDAOInterface {

    //delete review book
    @Override
    public void DeleteReview(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        String sql = "DELETE FROM [dbo].[Review] "
                + "      WHERE id=?";
        try {
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

    // update review book 
    @Override
    public void UpdateReview(Review review,String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "UPDATE [dbo].[Review] "
                    + "   SET [title] = ? "
                    + "      ,[content] = ? "
                    + "      ,[updatedAt] = ? "
                    + " WHERE id = ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, review.getTitle());
            ps.setString(2, review.getContent());
            ps.setDate(3, review.getUpdateAt());
            ps.setString(4, id);
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

    // add review book into database
    @Override
    public void CreateReview(Review review) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "INSERT INTO [dbo].[Review] "
                    + "           ([title] "
                    + "           ,[content] "
                    + "           ,[createdBy] "
                    + "           ,[bookId] "
                    + "           ,[createdAt])"
                    + "     VALUES "
                    + "           (?"
                    + "           ,?"
                    + "           ,?"
                    + "           ,?"
                    + "           ,?)";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, review.getTitle());
            ps.setString(2, review.getContent());
            ps.setString(3, String.valueOf(review.getCreateBy()));
            ps.setString(4, String.valueOf(review.getBookId()));
            ps.setDate(5, review.getCreatedAt());

            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

    //get all review which have book id
    @Override
    public ArrayList<Review> getListReviewByBook(int pagesize, int pageindex, String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Review> listReview = new ArrayList<>();
        try {
            String sql = "SELECT [id]\n"
                    + "      ,[title]\n"
                    + "      ,[content]\n"
                    + "      ,[createdBy]\n"
                    + "      ,[bookId]\n"
                    + "      ,[createdAt]\n"
                    + "      ,[updatedAt] \n"
                    + "FROM (SELECT ROW_NUMBER() OVER (ORDER BY [createdAt] DESC) as rownum, *  FROM Review \n"
                    + "WHERE [bookId] = ?) tbl WHERE \n"
                    + " rownum >= (? -1)*? + 1 AND rownum <= ? * ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            ps.setInt(2, pageindex);
            ps.setInt(3, pagesize);
            ps.setInt(4, pageindex);
            ps.setInt(5, pagesize);
            rs = ps.executeQuery();

            while (rs.next()) {
                Review review = new Review();
                review.setId(UUID.fromString(rs.getString("id")));
                review.setTitle(rs.getString("title"));
                review.setContent(rs.getString("content"));
                review.setCreateBy(UUID.fromString(rs.getString("createdBy")));
                review.setBookId(UUID.fromString(rs.getString("bookId")));
                review.setCreatedAt(rs.getDate("createdAt"));
                review.setCreatedAt(rs.getDate("updatedAt"));
                listReview.add(review);
            }
            return listReview;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

    //get all review which have user id
    @Override
    public ArrayList<Review> getListReviewByUser(int pagesize, int pageindex, String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Review> listReview = new ArrayList<>();
        try {
            String sql = "SELECT [id] "
                    + "      ,[title] "
                    + "      ,[content] "
                    + "      ,[createdBy] "
                    + "      ,[bookId] "
                    + "      ,[createdAt] "
                    + "      ,[updatedAt] "
                    + "FROM (SELECT ROW_NUMBER() OVER (ORDER BY [createdAt] DESC) as rownum, *  FROM Review "
                    + "WHERE [createdBy] = ?) tbl WHERE \n"
                    + " rownum >= (? -1)*? + 1 AND rownum <= ? * ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            ps.setInt(2, pageindex);
            ps.setInt(3, pagesize);
            ps.setInt(4, pageindex);
            ps.setInt(5, pagesize);
            rs = ps.executeQuery();

            while (rs.next()) {
                Review review = new Review();
                review.setId(UUID.fromString(rs.getString("id")));
                review.setTitle(rs.getString("title"));
                review.setContent(rs.getString("content"));
                review.setCreateBy(UUID.fromString(rs.getString("createdBy")));
                review.setBookId(UUID.fromString(rs.getString("bookId")));
                review.setCreatedAt(rs.getDate("createdAt"));
                review.setUpdateAt(rs.getDate("updatedAt"));
                listReview.add(review);
            }
            return listReview;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

    // Count number of review which have id =
    @Override
    public int countReviews(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Review> reviews = new ArrayList<>();
        String sql = "SELECT COUNT(*) as total FROM Review WHERE bookId = ?";
        try {
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return 0;
    }
// count number of reviews by user id

    @Override
    public int countReviewsByUserId(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Review> reviews = new ArrayList<>();
        String sql = " SELECT COUNT(*) as total FROM Review WHERE [createdBy] = ?";
        try {
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return 0;
    }

    // Get infor of review by id
    @Override
    public Review GetReviewById(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "SELECT [id] "
                    + "      ,[title] "
                    + "      ,[content] "
                    + "      ,[createdBy] "
                    + "      ,[bookId] "
                    + "      ,[createdAt] "
                    + "      ,[updatedAt] "
                    + "  FROM [dbo].[Review] WHERE [id] = ? ";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            Review review = new Review();
            while (rs.next()) {
                review.setId(UUID.fromString(rs.getString("id")));
                review.setCreateBy(UUID.fromString(rs.getString("createdBy")));
                review.setBookId(UUID.fromString(rs.getString("bookId")));
                review.setTitle(rs.getString("title"));
                review.setContent(rs.getString("content"));
                review.setCreatedAt(rs.getDate("createdAt"));
                review.setCreatedAt(rs.getDate("updatedAt"));
            }
            return review;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }
//    Get infor of the user indatabase by review id

    @Override
    public User getUserByReviewId(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "SELECT u.[id] "
                    + "   ,u.[firstName] "
                    + "   ,u.[lastName] "
                    + "	  ,r.[id] "
                    + "	  ,r.createdBy "
                    + "	  ,r.bookId "
                    + "	  ,b.name "
                    + "  FROM  Review r JOIN [User] u ON u.[id] = r.[createdBy] JOIN Book b ON b.id = r.bookId "
                    + "WHERE r.id = ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            User user = new User();
            while (rs.next()) {
                user.setFirstName(rs.getString("firstName"));
                user.setLastName(rs.getString("lastName"));
            }
            return user;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }
//    Get infor of the book indatabase by review id

    @Override
    public Book getBookByReviewId(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "SELECT u.[id] "
                    + "   ,u.[firstName] "
                    + "   ,u.[lastName] "
                    + "	  ,r.[id] "
                    + "	  ,r.createdBy "
                    + "	  ,r.bookId "
                    + "	  ,b.name "
                    + "  FROM  Review r JOIN [User] u ON u.[id] = r.[createdBy] JOIN Book b ON b.id = r.bookId "
                    + "WHERE r.id = ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            Book book = new Book();
            while (rs.next()) {
                book.setName(rs.getString("name"));
            }
            return book;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

}
