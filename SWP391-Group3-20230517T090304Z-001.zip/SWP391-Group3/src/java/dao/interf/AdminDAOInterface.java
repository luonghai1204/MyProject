/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.interf;

import java.sql.SQLException;
import java.util.ArrayList;
import model.Role;
import model.User;

/**
 *
 * @author Uchitachi
 */
public interface AdminDAOInterface {
    
//Function for admin'screen
    public ArrayList<User> getUser() throws SQLException;

    public ArrayList<User> getUserByUsername(String username) throws SQLException;

    public ArrayList<Role> getRole() throws SQLException;
    
    public User GetUserDetails(String id) throws SQLException;
    
    public void UpdateUser(User user) throws SQLException;
}
