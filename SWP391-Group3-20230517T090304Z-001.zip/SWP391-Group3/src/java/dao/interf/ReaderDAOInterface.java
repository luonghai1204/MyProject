/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.interf;

import java.sql.SQLException;
import java.util.ArrayList;
import model.Author;
import model.Book;
import model.BookType;

/**
 *
 * @author Uchitachi
 */
public interface ReaderDAOInterface {

    // Get list book
    public ArrayList<Book> getListBook(int pagesize, int pageindex) throws SQLException;
    // Get list book by text

    public ArrayList<Book> getListBookByName(int pagesize, int pageindex, String text) throws SQLException;

    // Get list type of the book
    public ArrayList<BookType> getListBookType() throws SQLException;
    // Count number of books in database

    public int countBooks() throws SQLException;
    // Count number of books in database

    public int countBooksHaveName(String name) throws SQLException;

    // Get book by id
    public Book GetBookById(String id) throws SQLException;
    // Get author ò the book

    public Author GetAuthorByBookId(String id) throws SQLException;
}
