/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.interf;

import java.sql.SQLException;
import java.util.ArrayList;
import model.Comment;
import model.User;

/**
 *
 * @author MSI
 */
public interface CommentDAOInterface {
     // Create comment by user
    public void CreateComment(String bookId, String userId, String content) throws SQLException;
    //Get username and userId
    public ArrayList<User> GetUsernameByBookId(String bookId) throws SQLException;
    // Get all comment of the book has specified
    public ArrayList<Comment> GetListComment(String bookId) throws SQLException;
    // Edit comment
    public void EditComment(String commentId, String content) throws SQLException;
    // Delete comment
    public void DeleteComment(String commentId) throws SQLException;
}
