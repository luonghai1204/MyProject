/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.interf;

import java.sql.SQLException;
import java.util.ArrayList;
import model.Book;
import model.Review;
import model.User;

/**
 *
 * @author Uchitachi
 */
public interface ReviewDAOInterface {
    // Get list review by bookid
    public ArrayList<Review> getListReviewByBook(int pagesize, int pageindex,String id) throws SQLException;
    // Get list review by user id
    public ArrayList<Review> getListReviewByUser(int pagesize, int pageindex,String id) throws SQLException;
    // Get review by review id
    public Review GetReviewById(String id) throws SQLException;
    // Delete review by review id
    public void DeleteReview(String id) throws SQLException;
    // Edit review 
    public void UpdateReview(Review review,String id) throws SQLException;
    // Add review into databse
    public void CreateReview(Review review) throws SQLException;
    // Count number of reviews in database by book id
    public int countReviews(String id) throws SQLException;
    // Count number of reviews in database by user id
    public int countReviewsByUserId(String id) throws SQLException;
    // Get list user
    public User getUserByReviewId(String id) throws SQLException;
    // Get list book
    public Book getBookByReviewId(String id) throws SQLException;
    
}
