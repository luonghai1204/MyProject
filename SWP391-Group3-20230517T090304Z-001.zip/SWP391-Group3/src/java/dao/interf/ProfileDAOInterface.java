/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.interf;

import java.sql.SQLException;
import model.User;

/**
 *
 * @author Uchitachi
 */
public interface ProfileDAOInterface {
    public User getInformationByUserName(String id) throws SQLException;
    public void editInformation(User u, String id) throws SQLException;
}
