/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.interf;

import java.sql.SQLException;
import java.util.ArrayList;
import model.Chapter;

/**
 *
 * @author Uchitachi
 */
public interface ChapterDAOInterface {
//    Get list chapter in database which have bookId
    public ArrayList<Chapter> getListChapterByBook(int pagesize, int pageindex,String id) throws SQLException;
//    Count number of chapter in a book
    public int countChapters(String id) throws SQLException;
    
}
