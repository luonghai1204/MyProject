/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dao.interf.ProfileDAOInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import model.User;

/**
 *
 * @author Uchitachi
 */
public class ProfileDAO extends DBContext implements ProfileDAOInterface{
    // Get information on account which was login successfull
    @Override
    public User getInformationByUserName(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        
        try {
            String sql = "SELECT * "
                    + "  FROM [dbo].[User] WHERE id = ?";
            
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            User u = null;
            while (rs.next()) {
                if (u == null) {
                    u = new User();
                    u.setId(UUID.fromString(rs.getString("id")));
                    u.setFirstName(rs.getString("firstName"));
                    u.setLastName(rs.getString("lastName"));
                    u.setEmail(rs.getString("email"));
                    u.setGender(rs.getBoolean("gender"));
                    u.setDob(rs.getDate("dob"));
                }
            }
            return u;

        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }

    }
    
    // Edit information of account
    @Override
    public void editInformation(User u, String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "UPDATE [dbo].[User]\n"
                    + "   SET [firstName] = ? "
                    + "      ,[lastName] = ? "
                    + "      ,[email] = ? "
                    + "      ,[gender] = ? "
                    + "      ,[dob] = ? "
                    + "      ,[updatedAt] = ? "
                    + " WHERE id = ?";

            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);

            ps.setString(1, u.getFirstName());
            ps.setString(2, u.getLastName());
            ps.setString(3, u.getEmail());
            ps.setBoolean(4, u.isGender());
            ps.setDate(5, u.getDob());
            ps.setDate(6, u.getUpdateAt());
            ps.setString(7, id);

            ps.executeUpdate();
        } catch (SQLException e) {
            throw e;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }

    }
}
