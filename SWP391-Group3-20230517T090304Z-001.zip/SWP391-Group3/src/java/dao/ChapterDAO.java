/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dao.interf.ChapterDAOInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import model.Chapter;

/**
 *
 * @author Uchitachi
 */
public class ChapterDAO extends DBContext implements ChapterDAOInterface {

    @Override
    public ArrayList<Chapter> getListChapterByBook(int pagesize, int pageindex, String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Chapter> listChapter = new ArrayList<>();
        try {
            String sql = "SELECT [id] "
                    + "      ,[bookId] "
                    + "      ,[order] "
                    + "      ,[name] "
                    + "      ,[content] "
                    + "      ,[imageCover] "
                    + "FROM (SELECT ROW_NUMBER() OVER (ORDER BY [order] ASC) as rownum, *  FROM [Chapter] "
                    + "WHERE [bookId] = ?) tbl WHERE "
                    + "rownum >= (? -1)*? + 1 AND rownum <= ? * ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            ps.setInt(2, pageindex);
            ps.setInt(3, pagesize);
            ps.setInt(4, pageindex);
            ps.setInt(5, pagesize);
            rs = ps.executeQuery();

            while (rs.next()) {
                Chapter chapter = new Chapter();
                chapter.setId(UUID.fromString(rs.getString("id")));
                chapter.setBookId(UUID.fromString(rs.getString("bookId")));
                chapter.setContent(rs.getString("content"));
                chapter.setName(rs.getString("name"));
                chapter.setImageCover(rs.getString("imageCover"));
                chapter.setOrder(rs.getInt("order"));

                listChapter.add(chapter);
            }
            return listChapter;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

    @Override
    public int countChapters(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Chapter> chapter = new ArrayList<>();
        String sql = "SELECT COUNT(*) as total FROM Chapter WHERE bookId = ?";
        try {
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return 0;
    }

    public ArrayList<Chapter> GetListChapterById(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;

        ArrayList<Chapter> listChapter = new ArrayList<>();
        try {
            String sql = "SELECT [id]\n"
                    + "      ,[bookId]\n"
                    + "      ,[order]\n"
                    + "      ,[name]\n"
                    + "      ,[content]\n"
                    + "      ,[imageCover]\n"
                    + "  FROM [dbo].[Chapter] Where bookId = ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                Chapter u = new Chapter();
                u.setId(UUID.fromString(rs.getString("id")));
                u.setBookId(UUID.fromString(rs.getString("bookId")));
                u.setName(rs.getString("name"));
                u.setOrder(rs.getInt("order"));
                u.setContent(rs.getString("content"));
                u.setImageCover(rs.getString("imagecover"));
                listChapter.add(u);
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return listChapter;
    }

    public void deleteChapter(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;

        try {
            String sql = "DELETE FROM [dbo].[Chapter]\n"
                    + "      where id = ?";

            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw e;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }
     public Chapter getChapterById(String id) throws SQLException {
        Chapter chapter = null;
        Connection connection = null;
        try {
            String sql = "SELECT [bookId]\n"
                    + "      ,[order]\n"
                    + "      ,[name]\n"
                    + "      ,[content]\n"
                    + "      ,[imageCover]\n"
                    + "  FROM [dbo].[Chapter]where id = ?";
            connection = openConnect(connection);
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(1, id);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                chapter = new Chapter();
                chapter.setId(UUID.fromString(id));
                chapter.setBookId(UUID.fromString(rs.getString("bookid")));
                chapter.setName(rs.getString("name"));
                chapter.setContent(rs.getString("content"));
                chapter.setImageCover(rs.getString("imagecover"));
                chapter.setOrder(rs.getInt("order"));
            }
        } catch (SQLException e) {
            throw e;
        }
        return chapter;
    }
     
      public void UpdateChapter(Chapter chapter, String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "UPDATE [dbo].[Chapter]\n"
                    + "   SET [bookId] = ?\n"
                    + "      ,[name] = ?\n"
                    + " WHERE [dbo].[Chapter].id=?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, String.valueOf(chapter.getBookId()));
            ps.setString(2, chapter.getName());
            ps.setString(3, id);
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

}
