/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dao.interf.AdminDAOInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import model.Role;
import model.User;

/**
 *
 * @author Uchitachi
 */
public class AdminDAO extends DBContext implements AdminDAOInterface {

    @Override
    public ArrayList<User> getUser() throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<User> users = new ArrayList<>();
        try {
            String sql = "SELECT [User].id, [User].username, [User].createdAt, [User].updatedAt,[User].isActive, [User].roleId from [dbo].[User]";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.setId(UUID.fromString(rs.getString("id")));
                user.setUsername(rs.getString("username"));
                user.setCreatedAt(rs.getDate("createdAt"));
                user.setUpdateAt(rs.getDate("updatedAt"));
                user.setIsActive(rs.getBoolean("isActive"));
                user.setRoleId(UUID.fromString(rs.getString("roleId")));
                users.add(user);
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return users;
    }

    @Override
    public ArrayList<User> getUserByUsername(String username) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<User> users = new ArrayList<>();
        try {
            String sql = "SELECT [User].id, [User].username, [User].createdAt, [User].updatedAt,[User].isActive, [User].roleId\n"
                    + "from [dbo].[User]\n"
                    + "where [User].username like '%" + username + "%'";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.setId(UUID.fromString(rs.getString("id")));
                user.setUsername(rs.getString("username"));
                user.setCreatedAt(rs.getDate("createdAt"));
                user.setUpdateAt(rs.getDate("updatedAt"));
                user.setIsActive(rs.getBoolean("isActive"));
                user.setRoleId(UUID.fromString(rs.getString("roleId")));
                users.add(user);
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return users;
    }

    @Override
    public ArrayList<Role> getRole() throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Role> roles = new ArrayList<>();
        try {
            String sql = "Select * from Role";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Role role = new Role();
                role.setName(rs.getString("name"));
                role.setId(UUID.fromString(rs.getString("id")));
                roles.add(role);
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return roles;
    }

    //Get infomation of user.
    @Override
    public User GetUserDetails(String id) throws SQLException {
       PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        User userDetails = new User();
        try {
            String sql = "select [User].id, [User].username, [User].[password], [User].firstName, [User].lastName, [User].email, [User].gender,[User].roleId, [User].dob,[User].isActive,[User].createdAt,[User].updatedAt \n"
                    + "from [dbo].[User] where [User].id='" + id + "'";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                userDetails.setId(UUID.fromString(rs.getString("id")));
                userDetails.setUsername(rs.getString("username"));
                userDetails.setPassword(rs.getString("password"));
                userDetails.setFirstName(rs.getString("firstName"));
                userDetails.setLastName(rs.getString("lastName"));
                userDetails.setEmail(rs.getString("email"));
                userDetails.setGender(rs.getBoolean("gender"));
                userDetails.setRoleId(UUID.fromString(rs.getString("roleId")));
                userDetails.setDob(rs.getDate("dob"));
                userDetails.setIsActive(rs.getBoolean("isActive"));
                userDetails.setCreatedAt(rs.getDate("createdAt"));
                userDetails.setUpdateAt(rs.getDate("updatedAt"));
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return userDetails;
    }

    //Update information for user.
    @Override
    public void UpdateUser(User user) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "UPDATE [dbo].[User]\n"
                    + "   SET \n"
                    + "      [isActive] = ?,\n"
                    + "     [roleId] = ?,\n"
                    + "	  [updatedAt] = GETDATE() \n"
                    + " WHERE [User].id = '" + String.valueOf(user.getId()) + "'";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setBoolean(1, user.isIsActive());
            ps.setString(2, String.valueOf(user.getRoleId()));
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

}
