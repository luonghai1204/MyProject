/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dao.interf.CommentDAOInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import model.Comment;
import model.User;

/**
 *
 * @author MSI
 */
public class CommentDAO extends DBContext implements CommentDAOInterface {

    @Override
    public void CreateComment(String bookId, String userId, String content) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "INSERT INTO [dbo].[Comment]\n"
                    + "           ([content]\n"
                    + "           ,[userId]\n"
                    + "           ,[bookId]\n"
                    + "           ,[createdAt])\n"
                    + "     VALUES\n"
                    + "           (?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,GETDATE())\n";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, content);
            ps.setString(2, userId);
            ps.setString(3, bookId);
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

    @Override
    public ArrayList<User> GetUsernameByBookId(String bookId) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<User> users = new ArrayList<>();
        try {
            String sql = "select u.id, u.username from [dbo].[User] u join [dbo].[Comment] c \n"
                    + "on u.id = c.userId join [dbo].Book b \n"
                    + "on c.bookId = b.id where b.id = ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, bookId);
            rs = ps.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.setId(UUID.fromString(rs.getString("id")));
                user.setUsername(rs.getString("username"));
                users.add(user);
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return users;
    }

    @Override
    public ArrayList<Comment> GetListComment(String bookId) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Comment> listComment = new ArrayList<>();
        try {
            String sql = "select * from Comment where bookId = ? order by createdAt desc";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, bookId);
            rs = ps.executeQuery();
            while (rs.next()) {
                Comment comment = new Comment();
                comment.setId(UUID.fromString(rs.getString("id")));
                comment.setContent(rs.getString("content"));
                comment.setUrl(rs.getString("url"));
                comment.setUserId(UUID.fromString(rs.getString("userId")));
                comment.setBookId(UUID.fromString(rs.getString("bookId")));
                comment.setCreatedAt(rs.getDate("createdAt"));
                comment.setUpdatedAt(rs.getDate("updatedAt"));
                listComment.add(comment);
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return listComment;
    }

    @Override
    public void EditComment(String commentId, String content) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "UPDATE [dbo].[Comment]\n"
                    + "   SET [content] = ?\n"
                    + " WHERE [dbo].[Comment].id = ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, content);
            ps.setString(2, commentId);
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

    @Override
    public void DeleteComment(String commentId) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "DELETE FROM [dbo].[Comment]\n"
                    + "      WHERE [dbo].[Comment].id = ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, commentId);
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

}
