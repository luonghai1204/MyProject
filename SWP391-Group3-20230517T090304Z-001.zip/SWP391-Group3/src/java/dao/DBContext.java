/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Uchitachi
 */
public abstract class DBContext {

    public DBContext() {
    }

    public Connection openConnect(Connection conn) {
        try {
            String url = "jdbc:sqlserver://localhost:1433;databaseName=ProjectSWP391";
            String user = "sa1";
            String pass = "123";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conn = DriverManager.getConnection(url, user, pass);
            
        } catch (Exception ex) {
            Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
        }
        return conn;
    }

    /**
     * This function closes ResultSet
     *
     * @param rs the ResultSet. It is a java.sql.ResultSet object
     * @throws SQLException
     */
    public void closeRs(ResultSet rs) throws SQLException {
        if (rs != null && !rs.isClosed()) {
            rs.close();
        }
    }

    /**
     * This function closes Prepared Statement
     *
     * @param ps the PreparedStatement. It is a java.sql.PreparedStatement
     * object
     * @throws SQLException
     */
    public void closePs(PreparedStatement ps) throws SQLException {
        if (ps != null && !ps.isClosed()) {
            ps.close();
        }
    }

    /**
     * This function closes Connection
     *
     * @param con the Connection. It is a class java.sql.Connection object
     * @throws SQLException
     */
    public void closeCon(Connection con) throws SQLException {
        if (con != null && !con.isClosed()) {
            con.close();
        }
    }
}
