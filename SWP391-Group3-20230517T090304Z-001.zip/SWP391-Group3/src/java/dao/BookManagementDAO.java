/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dao.interf.BookManagementDAOInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import model.Book;
import model.BookType;
import model.Chapter;

/**
 *
 * @author Uchitachi
 */
public class BookManagementDAO extends DBContext implements BookManagementDAOInterface {

    // Get list type in database    
    @Override
    public ArrayList<BookType> getListBookType() throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<BookType> bookTypes = new ArrayList<>();
        try {
            String sql = "SELECT * from [dbo].[BookType]";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                BookType bookType = new BookType();
                bookType.setId(UUID.fromString(rs.getString("id")));
                bookType.setName(rs.getString("name"));
                bookType.setDescription(rs.getString("description"));
                bookType.setCreatedAt(rs.getDate("createdAt"));
                bookType.setUpdatedAt(rs.getDate("updatedAt"));
                bookTypes.add(bookType);
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return bookTypes;
    }
    
    // Get list of book
    @Override
    public ArrayList<Book> getListBook(int pagesize, int pageindex) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Book> books = new ArrayList<>();
        String sql = "SELECT [id],[name],[description],[imageCover],[source]"
                + ",[status],[bookTypeId],[deleted],[createdAt],[updatedAt] "
                + "FROM (SELECT ROW_NUMBER() OVER (ORDER BY [createdAt] DESC) as rownum, *  FROM Book WHERE deleted = 'false') tbl WHERE "
                + "rownum >= (? -1)*? + 1 AND rownum <= ? * ?";
        try {
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setInt(1, pageindex);
            ps.setInt(2, pagesize);
            ps.setInt(3, pageindex);
            ps.setInt(4, pagesize);
            rs = ps.executeQuery();
            while (rs.next()) {
                Book book = new Book();
                book.setId(UUID.fromString(rs.getString("id")));
                book.setName(rs.getString("name"));
                book.setDescription(rs.getString("description"));
                book.setImageCover(rs.getString("imageCover"));
                book.setSource(rs.getString("source"));
                book.setStatus(rs.getString("status"));
//                book.setBookTypeId(UUID.fromString(rs.getString("bookTypeId")));
                book.setDeleted(rs.getBoolean("deleted"));
                book.setCreatedAt(rs.getDate("createdAt"));
                book.setUpdatedAt(rs.getDate("updatedAt"));

                books.add(book);
            } 
            return books;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }

    }

    
    //  Delete book by id in database
    @Override
    public void DeleteBook(String id) throws SQLException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        String sql = "DELETE FROM [dbo].[Book] "
                + "      WHERE id=?";
        try {
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }

    }
    
    // Update information of the book  
    @Override
    public void UpdateBook(Book book) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "UPDATE [dbo].[Book]\n"
                    + "   SET [name] = ?\n"
                    + "      ,[description] = ?\n"
                    + "      ,[imageCover] = ?\n"
                    + "      ,[source] = ?\n"
                    + "      ,[status] = ?\n"
                    + "      ,[deleted] = ?\n"
                    + "      ,[updatedAt] = GETDATE()\n"
                    + " WHERE [dbo].Book.id = '" + book.getId() + "'";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, book.getName());
            ps.setString(2, book.getDescription());
            ps.setString(3, book.getImageCover());
            ps.setString(4, book.getSource());
            ps.setString(5, book.getStatus());
            ps.setBoolean(6, book.isDeleted());
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

    // Add book to databse
    @Override
    public void CreateBook(Book book,BookType bookType) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "INSERT INTO [dbo].[Book]\n"
                    + "           ([name]\n"
                    + "           ,[description]\n"
                    + "           ,[imageCover]\n"
                    + "           ,[source]\n"
                    + "           ,[status]\n"
                    + "           ,[bookTypeId]\n"
                    + "           ,[deleted]\n"
                    + "           ,[createdAt])\n"
                    + "     VALUES(?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,GETDATE())";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, book.getName());
            ps.setString(2, book.getDescription());
            ps.setString(3, book.getImageCover());
            ps.setString(4, book.getSource());
            ps.setString(5, book.getStatus());
            ps.setString(6, String.valueOf(bookType.getId()));
            ps.setBoolean(7, book.isDeleted());
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

    // Count number of book in database 
    @Override
    public int countBooks() throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Book> novals = new ArrayList<>();
        String sql = "SELECT COUNT(*) as total FROM Book";
        try {
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return 0;
    }

    //Get type of a book
    @Override
    public ArrayList<BookType> getTypeOfBook() throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<BookType> bookTypes = new ArrayList<>();
        try {
            String sql = "select [dbo].BookType.id, [dbo].BookType.[name] from [dbo].BookType";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                BookType bookType = new BookType();
                bookType.setId(UUID.fromString(rs.getString("id")));
                bookType.setName(rs.getString("name"));
                bookTypes.add(bookType);
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return bookTypes;
    }

    // Get information of book by id 
    @Override
    public Book GetBookById(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "select * from [dbo].Book where [dbo].Book.id = '" + id + "'";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            Book book = new Book();
            while (rs.next()) {
                book.setId(UUID.fromString(rs.getString("id")));
                book.setName(rs.getString("name"));
                book.setDescription(rs.getString("description"));
                book.setImageCover(rs.getString("imageCover"));
                book.setSource(rs.getString("source"));
                book.setStatus(rs.getString("status"));
                book.setBookTypeId(UUID.fromString(rs.getString("bookTypeId")));
                book.setDeleted(rs.getBoolean("deleted"));
                book.setCreatedAt(rs.getDate("createdAt"));
                book.setUpdatedAt(rs.getDate("updatedAt"));
            }
            return book;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }
    
    
    public ArrayList<Integer> GetChapterExistById(String bookId) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            ArrayList<Integer> listChapter = new ArrayList<>();
            String sql = "  select Chapter.[order] from Chapter where bookId =?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, bookId);
            rs = ps.executeQuery();
            while (rs.next()) {
                listChapter.add(rs.getInt("order"));
            }
            return listChapter;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }
    
    public void CreateChapter(Book book, Chapter chapter) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "INSERT INTO [dbo].[Chapter]\n"
                    + "           ([bookId]\n"
                    + "           ,[order]\n"
                    + "           ,[name]\n"
                    + "           ,[content]\n"
                    + "           ,[imageCover])\n"
                    + "     VALUES\n"
                    + "           (?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?)\n";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, String.valueOf(book.getId()));
            ps.setInt(2, chapter.getOrder());
            ps.setString(3, chapter.getName());
            ps.setString(4, chapter.getContent());
            ps.setString(5, chapter.getImageCover());
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

}
