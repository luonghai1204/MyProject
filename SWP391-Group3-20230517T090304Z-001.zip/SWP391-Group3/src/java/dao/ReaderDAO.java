/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dao.interf.ReaderDAOInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;
import model.Author;
import model.Book;
import model.BookType;

/**
 *
 * @author Uchitachi
 */
public class ReaderDAO extends DBContext implements ReaderDAOInterface {

//    Get list book iin database
    @Override
    public ArrayList<Book> getListBook(int pagesize, int pageindex) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Book> books = new ArrayList<>();
        String sql = "SELECT [id],[name],[description],[imageCover],[source]"
                + ",[status],[bookTypeId],[deleted],[createdAt],[updatedAt] "
                + "FROM (SELECT ROW_NUMBER() OVER (ORDER BY [createdAt] DESC) as rownum, *  FROM Book WHERE deleted = 'false') tbl WHERE "
                + "rownum >= (? -1)*? + 1 AND rownum <= ? * ?";
        try {
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setInt(1, pageindex);
            ps.setInt(2, pagesize);
            ps.setInt(3, pageindex);
            ps.setInt(4, pagesize);
            rs = ps.executeQuery();
            while (rs.next()) {
                Book book = new Book();
                book.setId(UUID.fromString(rs.getString("id")));
                book.setName(rs.getString("name"));
                book.setDescription(rs.getString("description"));
                book.setImageCover(rs.getString("imageCover"));
                book.setSource(rs.getString("source"));
                book.setStatus(rs.getString("status"));
//                book.setBookTypeId(UUID.fromString(rs.getString("bookTypeId")));
                book.setDeleted(rs.getBoolean("deleted"));
                book.setCreatedAt(rs.getDate("createdAt"));
                book.setUpdatedAt(rs.getDate("updatedAt"));

                books.add(book);
            }
            return books;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }
//    Get list book in database by name 
    @Override
    public ArrayList<Book> getListBookByName(int pagesize, int pageindex, String text) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Book> books = new ArrayList<>();
        String sql = "SELECT [id],[name],[description],[imageCover],[source]"
                + ",[status],[bookTypeId],[deleted],[createdAt],[updatedAt] "
                + "FROM (SELECT ROW_NUMBER() OVER (ORDER BY [createdAt] DESC) as rownum, *  FROM Book WHERE deleted = 'false' AND name = ?) tbl WHERE "
                + "rownum >= (? -1)*? + 1 AND rownum <= ? * ?";
        try {
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, text);
            ps.setInt(2, pageindex);
            ps.setInt(3, pagesize);
            ps.setInt(4, pageindex);
            ps.setInt(5, pagesize);
            rs = ps.executeQuery();
            while (rs.next()) {
                Book book = new Book();
                book.setId(UUID.fromString(rs.getString("id")));
                book.setName(rs.getString("name"));
                book.setDescription(rs.getString("description"));
                book.setImageCover(rs.getString("imageCover"));
                book.setSource(rs.getString("source"));
                book.setStatus(rs.getString("status"));
//                book.setBookTypeId(UUID.fromString(rs.getString("bookTypeId")));
                book.setDeleted(rs.getBoolean("deleted"));
                book.setCreatedAt(rs.getDate("createdAt"));
                book.setUpdatedAt(rs.getDate("updatedAt"));

                books.add(book);
            }
            return books;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }
//    Get list bookType in database
    @Override
    public ArrayList<BookType> getListBookType() throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<BookType> bookTypes = new ArrayList<>();
        try {
            String sql = "SELECT * from [dbo].[BookType]";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                BookType bookType = new BookType();
                bookType.setId(UUID.fromString(rs.getString("id")));
                bookType.setName(rs.getString("name"));
                bookType.setDescription(rs.getString("description"));
                bookType.setCreatedAt(rs.getDate("createdAt"));
                bookType.setUpdatedAt(rs.getDate("updatedAt"));
                bookTypes.add(bookType);
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return bookTypes;
    }

//    count number of the books in database
    @Override
    public int countBooks() throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Book> novals = new ArrayList<>();
        String sql = "SELECT COUNT(*) as total FROM Book";
        try {
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return 0;
    }
    
//    count number of the books in database which have name
    @Override
    public int countBooksHaveName(String name) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        ArrayList<Book> novals = new ArrayList<>();
        String sql = "SELECT COUNT(*) as total FROM Book where name = ?";
        try {
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, name);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
        return 0;
    }

//    get book in database which have id =
    @Override
    public Book GetBookById(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "select * from [dbo].Book where [dbo].Book.id = '" + id + "'";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            Book book = new Book();
            while (rs.next()) {
                book.setId(UUID.fromString(rs.getString("id")));
                book.setName(rs.getString("name"));
                book.setDescription(rs.getString("description"));
                book.setImageCover(rs.getString("imageCover"));
                book.setSource(rs.getString("source"));
                book.setStatus(rs.getString("status"));
//                book.setBookTypeId(UUID.fromString(rs.getString("bookTypeId")));
                book.setDeleted(rs.getBoolean("deleted"));
                book.setCreatedAt(rs.getDate("createdAt"));
                book.setUpdatedAt(rs.getDate("updatedAt"));
            }
            return book;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }
//    get Author of the book
    @Override
    public Author GetAuthorByBookId(String id) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = null;
        try {
            String sql = "SELECT b.id,a.id,a.[name],ba.id,ba.bookId,ba.authorId "
                    + "FROM Book b JOIN BookAuthor ba ON b.id = ba.bookId JOIN "
                    + "Author a ON a.id = ba.authorId "
                    + "WHERE b.id = ?";
            connection = openConnect(connection);
            ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            Author author = new Author();
            while (rs.next()) {
//                author.setId(UUID.fromString(rs.getString("bookId")));
                author.setName(rs.getString("name"));
            }
            return author;
        } catch (SQLException ex) {
            throw ex;
        } finally {
            closePs(ps);
            closeRs(rs);
            closeCon(connection);
        }
    }

}
