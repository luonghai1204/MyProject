/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.UUID;

/**
 *
 * @author Uchitachi
 */
public class Chapter {
    private UUID id;
    private UUID bookId;
    private int order;
    private String name;
    private String content;
    private String imageCover;

    public Chapter() {
    }

    public Chapter(UUID id, UUID bookId, int order, String name, String content, String imageCover) {
        this.id = id;
        this.bookId = bookId;
        this.order = order;
        this.name = name;
        this.content = content;
        this.imageCover = imageCover;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getBookId() {
        return bookId;
    }

    public void setBookId(UUID bookId) {
        this.bookId = bookId;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getImageCover() {
        return imageCover;
    }

    public void setImageCover(String imageCover) {
        this.imageCover = imageCover;
    }
    
}
