/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;
import java.util.UUID;

/**
 *
 * @author Uchitachi
 */
public class Review {
    private UUID id;
    private String title;
    private String content;
    private UUID createBy;
    private UUID bookId;
    private Date createdAt;
    private Date updateAt;

    public Review() {
    }

    public Review(UUID id, String title, String content, UUID createBy, UUID bookId, Date createdAt, Date updateAt) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.createBy = createBy;
        this.bookId = bookId;
        this.createdAt = createdAt;
        this.updateAt = updateAt;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public UUID getCreateBy() {
        return createBy;
    }

    public void setCreateBy(UUID createBy) {
        this.createBy = createBy;
    }

    public UUID getBookId() {
        return bookId;
    }

    public void setBookId(UUID bookId) {
        this.bookId = bookId;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(Date updateAt) {
        this.updateAt = updateAt;
    }
    
}
