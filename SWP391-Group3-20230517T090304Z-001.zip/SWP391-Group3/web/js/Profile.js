function validate(id) {

    var form = document.querySelector(id);

    var error = form.querySelectorAll('.error');
    var element_input = form.querySelectorAll('.element_input');
    var date = form.querySelector('#date');
    var error_text = form.querySelector('.error_text');
    var regax = /^[a-zA-Z0-9]{5,50}@gmail\.com$/;


    var today = new Date();
    var date_val = new Date(date.value);

    console.log(today)

    let progress_num = 0;
    let num_empty = 0;
    let num_email = 0;
    let num_date = 0;
    num_length = 0;

    num_length = checkLength(element_input);
    num_empty = checkEmpty(element_input);
    num_email = checkEmail(element_input, regax);
    num_date = checkBirthDate(today, date_val);


    function checkBirthDate(today, date_val) {
        var num = 0;
        if (date_val.getDate() > today.getDate() && today.getFullYear() == date_val.getFullYear()) {
            error[3].innerHTML = "Must be less than curren time";
            num++;
        } else if (today.getFullYear() - date_val.getFullYear() < 12) {
            error[3].innerHTML = "User must be more than 12 years old";
            num++;
        } else {
            return num;
        }
        return num;
    }


    function checkEmpty(element_input) {
        let num = 0;
        for (let i = 0; i < element_input.length; i++) {
            if (element_input[i].value.trim() === "") {
                error[i].innerHTML = "empty value";
                num++;
            }
            element_input[i].addEventListener('click', function () {
                error[i].innerHTML = '';    
            })
        }
        return num;
    }

    function checkEmail(element_input, regax) {
        let num = 0;
        for (let i = 0; i < element_input.length; i++) {
            if (element_input[2].value.match(regax)) {
                return num;
            } else {
                error[2].innerHTML = "Email doesn't match the format( 5-15 characters + @gmail.com) ";
                num++;
            }

        }
        return num;
    }

    function checkLength(element_input) {
        let num = 0;
        for (let i = 0; i < element_input.length; i++) {
            if (element_input[0].value.length > 50) {
                error[0].innerHTML = "First name must be less than 50 character";
                num++;
            } else if (element_input[1].value.length > 50) {
                error[1].innerHTML = "Last name must be less than 50 character";
                num++;
            } else if (element_input[2].value.length > 100) {
                error[2].innerHTML = "Username must be less than 100 character";
                num++;
            }
        }
        return num;
    }



    progress_num = num_empty + num_email + num_length+num_date;

    if (progress_num > 0) {
        return false;
    } else {
        return true;
    }

}
