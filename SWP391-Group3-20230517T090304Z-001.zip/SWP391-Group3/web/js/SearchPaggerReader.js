/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function renderPagerSearch(container,pageindex,totalpage,gap,text)
{
    console.log(text);
    var div_container = document.getElementById(container);
    var content = "";
    if(pageindex - gap > 1)
        content += "<a href=\"home?page=1&textSearch="+text+"\">First</a>";
    for(var i=pageindex-gap;i<pageindex;i++)
        if(i > 0)
            content += "<a href=\"home?page="+i+"&textSearch="+text+"\">"+i+"</a>";
    
    content += "<span>" + pageindex + "</span>";
    
    for(var i=pageindex+1;i<pageindex + gap;i++)
        if(i <= totalpage)
            content += "<a href=\"home?page="+i+"&textSearch="+text+"\">"+i+"</a>";
    
    if(pageindex + gap < totalpage)
        content += "<a href=\"home?page="+totalpage+"&textSearch="+text+"\">Last</a>";
    
    div_container.innerHTML = content;
    
}

