/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function validate(id) {

    var form = document.querySelector(id);
    var error = form.querySelectorAll('.error');

    let progress_num = 0;
    let num_empty = 0;
    let num_checkLength = 0;

    var element_input = form.querySelectorAll('.form-control');
    num_empty = checkEmpty(element_input);
    num_checkLength = checkLength(element_input);

    function checkEmpty(element_input) {
        let num = 0;
        for (let i = 0; i < element_input.length; i++) {
            if (element_input[i].value.trim() === "") {
                error[i].innerHTML = "Value is not empty.";
                num++;
            }

            element_input[i].addEventListener('click', function () {
                error[i].innerHTML = '';

            });
        }
        return num;
    }

    function checkLength(element_input) {
        let num = 0;
        for (let i = 0; i < element_input.length; i++) {
            if (element_input[0].value.length > 20) {
                error[0].innerHTML = "Book's name must be less than 20 character";
                num++;
            } else if (element_input[1].value.length > 200) {
                error[1].innerHTML = "Book's description must be less than 200 character";
                num++;
            } else if (element_input[3].value.length > 100) {
                error[2].innerHTML = "Book's sourcce must be less than 100 character";
                num++;
            }


        }
        return num;
    }

    progress_num = num_empty + num_checkLength;

    console.log(num_empty);

    if (progress_num > 0) {
        return false;
    } else {
        return true;
    }

}

