/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function validate(id){
    var form = document.querySelector(id);

    var error = form.querySelectorAll('.error');
    var element_input = form.querySelectorAll('.element_input');


    let progress_num = 0;
    let num_empty = 0;
    let num_length = 0;
    num_empty = checkEmpty(element_input);
    num_length = checkLength(element_input);

    function checkEmpty(element_input) {
        let num = 0;
        for (let i = 0; i < element_input.length; i++) {
            if (element_input[i].value.trim() === "") {
                error[i].innerHTML = "empty value";
                num++;
            }

            element_input[i].addEventListener('click', function () {
                error[i].innerHTML = '';
                
            });


        }
        return num;
    }



    function checkLength(element_input){
        let num = 0;
        for (let i = 0; i < element_input.length; i++) {
            if (element_input[0].value.length > 50) {
                error[0].innerHTML = "First name must be less than 50 character";
                num++;
            }else if(element_input[1].value.length > 50){
                error[1].innerHTML = "Last name must be less than 50 character";
                num++;
            }
        }
        return num;
    }



    progress_num = num_empty+num_length;
    
    if (progress_num > 0) {
        return false;
    } else {
        return true;
    }

}

